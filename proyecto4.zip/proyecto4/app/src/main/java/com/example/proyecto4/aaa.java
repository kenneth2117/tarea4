package com.example.proyecto4;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class aaa extends RecyclerView.Adapter<aaa.jj>{


    @NonNull
    @Override
    public aaa.jj onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return null;
    }

    @Override
    public void onBindViewHolder(@NonNull aaa.jj holder, int position) {

    }

    @Override
    public int getItemCount() {
        return 0;
    }

    public class jj extends RecyclerView.ViewHolder {
        public jj(@NonNull View itemView) {
            super(itemView);
        }
    }
}
